
//Assignment 1 by pirple.com

let songName: String = "Kabira(Encore)"
//there are two versions of this song i.e Kabira  and Kabira (Encore)


let movie: String = "Yeh Jawaani Hai Deewani"
var artist: String = "Arijit Singh"
/*
 As the song comprises of vesions
 So, there many other singers than Arijit Singh
 they are:-
 Tochi Raina     (Non Encore version)
 Rekha Bhardwaj  (Non Encore version)
 Harshdeep Kaur  (for encore version)
 */

let year: Int = 2013
let duration: Float = 4.30
let femaleLeadCast: String = "Deepika Padukone"
let maleLeadCast: String = "Rabir Kapoor"
var genre: String = "Sufi Pop"
let lyricist: String = "Amitabh Bhattacharya"

print(" My all time favourite song is \(songName) of movie \" \(movie) \". \n The movie was released in year \(year). \n The  movie was big hit on Indian Box Office.\n With the lead roles played by actor \(maleLeadCast) and \(femaleLeadCast).\n It's a \(duration) minutes song sung by by the legendary singer \(artist) and the lyrics was written by the lyricist \(lyricist).\n The song is considered under the \(genre) genre. ")


//printing the statements 
